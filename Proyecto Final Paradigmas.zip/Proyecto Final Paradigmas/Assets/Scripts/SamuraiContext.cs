public static class SamuraiContext
{
    // Para que el tracker ignore el SushiPoint generado por el corte del samurái
    public static int LastSamuraiSliceFrame = -1;
}


