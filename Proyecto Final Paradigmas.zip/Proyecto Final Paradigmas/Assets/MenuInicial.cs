using UnityEngine;
using UnityEngine.SceneManagement;

public class MenuInicial : MonoBehaviour
{
    public void Jugar()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }

    public void IrAShop()
    {
        SceneManager.LoadScene("Shop");
    }

    public void Salir()
    {
        Debug.Log("Salir...");

        // Cierra en build
        Application.Quit();

#if UNITY_EDITOR
        // Para el Play Mode en el Editor
        UnityEditor.EditorApplication.isPlaying = false;
#endif
    }
}