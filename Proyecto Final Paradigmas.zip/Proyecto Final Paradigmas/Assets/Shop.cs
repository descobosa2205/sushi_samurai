using UnityEngine;
using UnityEngine.SceneManagement;

public class Shop : MonoBehaviour
{
    [SerializeField] private CoinUI coinUI;
    [SerializeField] private ShopItemUI[] itemUIs;

    private void Start()
    {
        coinUI?.UpdateCoins();
        RefreshUI();
    }

    private void OnEnable()
    {
        coinUI?.UpdateCoins();
        RefreshUI();
    }

    private void RefreshUI()
    {
        if (itemUIs == null || itemUIs.Length == 0)
            //itemUIs = FindObjectsOfType<ShopItemUI>(true);
            itemUIs = FindObjectsByType<ShopItemUI>(FindObjectsInactive.Include, FindObjectsSortMode.None);

        foreach (var ui in itemUIs)
            ui.Refresh();
    }

    public void Volver()
    {
        SceneManager.LoadScene("MenuInicial");
    }

    public void SelectWood()
    {
        PlayerData.TryBuyAndSelect(BackgroundType.Wood);
        coinUI?.UpdateCoins();
        RefreshUI();
    }

    public void SelectRio()
    {
        TrySelectWithFeedback(BackgroundType.Rio);
    }

    public void SelectCocina()
    {
        TrySelectWithFeedback(BackgroundType.Cocina);
    }

    public void SelectTerraza()
    {
        TrySelectWithFeedback(BackgroundType.Terraza);
    }

    private void TrySelectWithFeedback(BackgroundType bg)
    {
        bool success = PlayerData.TryBuyAndSelect(bg);

        if (!success)
        {
            int price = PlayerData.GetPrice(bg);
        }

        coinUI?.UpdateCoins();
        RefreshUI();
    }
}